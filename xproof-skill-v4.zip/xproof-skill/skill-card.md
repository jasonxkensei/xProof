# xProof — Prove Before Act for AI Agents

> **No API key needed.** Any agent can anchor a proof and pay per call via x402 — one HTTP request, no account, no setup.

## What it does

xProof anchors your agent’s reasoning (WHY) and planned action (WHAT) on the MultiversX blockchain *before* executing. The result is an immutable, publicly verifiable 4W audit trail (Who, What, When, Why) — the accountability layer for autonomous agents.

**Privacy-first**: only the SHA-256 hash is anchored on-chain. Raw content never leaves the agent.

## Quick start (30 seconds)

```bash
# 1. Get 10 free proofs — no wallet, no card
curl -X POST https://xproof.app/api/agent/register \
  -H "Content-Type: application/json" \
  -d '{"agent_name": "my-agent"}'
# → { "api_key": "pm_..." }

# 2. Hash your file locally
sha256sum reasoning.json
# → a1b2c3...64hex

# 3. Anchor proof before executing
curl -X POST https://xproof.app/api/proof \
  -H "Authorization: Bearer pm_..." \
  -H "Content-Type: application/json" \
  -d '{"file_hash":"a1b2c3...","filename":"reasoning.json","metadata":{"why":"RSI=38, oversold","what":"BUY BTC 0.5"}}'
# → { "proof_id": "...", "verify_url": "/proof/..." }
```

## x402 — fully autonomous (no API key)

Any agent with a USDC wallet on Base can anchor proofs without any account:

```
POST /api/proof → 402 with price ($0.05 USDC on Base)
Resend + X-PAYMENT header → proof anchored immediately
```

## MCP

```
POST https://xproof.app/mcp
Tools: certify_file · audit_agent_session · verify_proof · investigate_proof · register_free_trial
```

## Proven in production

**xproof_agent_verify** (Moltbook): 4,418 proofs · 100% confirmation rate · 16-week streak · Trust score 43,326

## Pricing

| Volume | Price |
|--------|-------|
| Free trial | 10 proofs, no wallet |
| 0 – 100k | $0.05 / proof |
| 100k – 1M | $0.025 / proof |
| 1M+ | $0.01 / proof |

## Links

- Platform: https://xproof.app
- Agent context: https://xproof.app/agent-context
- MCP endpoint: https://xproof.app/mcp
- Live agent profile: https://xproof.app/agent/erd1hlx4xanncp2wm9aly2q6ywuthl2q9jwe9sxvxpx4gg62zcrvd0uqr8gyu9
